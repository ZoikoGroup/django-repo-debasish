from django.contrib import admin
from .models import Plan, PlanType


@admin.register(PlanType)
class PlanTypeAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'parent', 'created_at')
    search_fields = ('name',)
    prepopulated_fields = {'slug': ('name',)}
    list_filter = ('parent',)


@admin.register(Plan)
class PlanAdmin(admin.ModelAdmin):
    list_display = (
        'id',
        'title',
        'plan_type',
        'price',
        'status',
        'created_at',
    )

    list_display_links = ('id', 'title')
    list_filter = ('status', 'plan_type')
    search_fields = ('title', 'tag', 'sub_title')
    ordering = ('order', 'title')
    prepopulated_fields = {"slug": ("title",)}

    # 🔴 VERY IMPORTANT: features must be editable
    # DO NOT add readonly_fields

    class Media:
        js = ("admin/js/plan_features.js",)
