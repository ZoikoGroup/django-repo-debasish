from django.urls import path
from .api_views import (
    PlanListAPI,
    PlanByTypeAPI,
)

urlpatterns = [
    path('plans/', PlanListAPI.as_view(), name='plan-list'),
    path('plans/type', PlanByTypeAPI.as_view(), name='plan-by-type'),
]
