from django import forms
from .models import Plan, PlanType


class PlanForm(forms.ModelForm):
    class Meta:
        model = Plan
        fields = [
            # Basic info
            'title',
            'slug',
            'sub_title',
            'tag',

            # Plan type
            'plan_type',

            # Pricing
            'price',
            'sale_price',
            'currency',

            # Duration & SIM
            'duration_type',
            'duration_value',
            'call_duration',
            'sim_type',

            # Media
            'featured_image',
            'image_url',

            # Features (JSON)
            'features',

            # SEO
            'meta_title',
            'meta_slug',
            'meta_description',

            # Status & ordering
            'status',
            'order',
        ]

        widgets = {
            'title': forms.TextInput(attrs={'class': 'form-control'}),
            'slug': forms.TextInput(attrs={'class': 'form-control'}),
            'sub_title': forms.TextInput(attrs={'class': 'form-control'}),
            'tag': forms.TextInput(attrs={'class': 'form-control'}),

            # FK should be Select
            'plan_type': forms.Select(attrs={'class': 'form-control'}),

            'price': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01'}),
            'sale_price': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01'}),
            'currency': forms.TextInput(attrs={'class': 'form-control'}),

            'duration_type': forms.Select(attrs={'class': 'form-control'}),
            'duration_value': forms.TextInput(attrs={'class': 'form-control'}),
            'call_duration': forms.TextInput(attrs={'class': 'form-control'}),
            'sim_type': forms.TextInput(attrs={'class': 'form-control'}),

            # ✅ FIXED
            'featured_image': forms.FileInput(attrs={'class': 'form-control'}),

            'image_url': forms.TextInput(attrs={'class': 'form-control'}),

            'features': forms.Textarea(
                attrs={
                    'class': 'form-control',
                    'rows': 4,
                    'placeholder': '[{"icon_url": "url", "text": "Feature text"}]'
                }
            ),

            'meta_title': forms.TextInput(attrs={'class': 'form-control'}),
            'meta_slug': forms.TextInput(attrs={'class': 'form-control'}),
            'meta_description': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),

            'status': forms.Select(attrs={'class': 'form-control'}),
            'order': forms.NumberInput(attrs={'class': 'form-control'}),
        }
