from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from .models import Plan, PlanType
from .serializers import PlanSerializer
from .utils import decrypt_string

class PlanListAPI(APIView):
    def get(self, request):
        plans = Plan.objects.select_related('plan_type').all()
        serializer = PlanSerializer(plans, many=True)
        return Response({
            "success": True,
            "count": plans.count(),
            "data": serializer.data
        })

class PlanByTypeAPI(APIView):
    def get(self, request):
        encrypted_ids = request.GET.get('id')
        slugs = request.GET.get('slug')

        plans = Plan.objects.none()

        if encrypted_ids:
            try:
                type_ids = decrypt_string(encrypted_ids)
                plans = Plan.objects.filter(plan_type_id__in=type_ids)
            except Exception:
                return Response(
                    {"error": "Invalid encrypted id"},
                    status=status.HTTP_400_BAD_REQUEST
                )

        elif slugs:
            try:
                slug_list = decrypt_string(slugs)
                plans = Plan.objects.filter(plan_type__slug__in=slug_list)
            except Exception:
                return Response(
                    {"error": "Invalid encrypted slug"},
                    status=status.HTTP_400_BAD_REQUEST
                )


        else:
            return Response(
                {"error": "Either id or slug parameter is required"},
                status=status.HTTP_400_BAD_REQUEST
            )

        serializer = PlanSerializer(plans, many=True)

        return Response({
            "success": True,
            "count": plans.count(),
            "data": serializer.data
        })

