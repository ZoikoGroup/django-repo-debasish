from django.db import models
from django.utils.text import slugify


class PlanType(models.Model):
    id = models.BigAutoField(primary_key=True)

    parent = models.ForeignKey(
        'self',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='children'
    )

    name = models.CharField(max_length=255)
    slug = models.SlugField(max_length=255, unique=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['name']
        db_table = 'plan_types'

    def __str__(self):
        return self.name

    def save(self, *args, **kwargs):
        if not self.slug:
            self.slug = slugify(self.name)
        super().save(*args, **kwargs)


class Plan(models.Model):
    STATUS_CHOICES = [
        ('active', 'Active'),
        ('inactive', 'Inactive'),
        ('deleted', 'Deleted'),
    ]

    DURATION_CHOICES = [
        ('day', 'Day'),
        ('week', 'Week'),
        ('month', 'Month'),
        ('year', 'Year'),
        ('mo', 'Month (mo)'),
    ]

    id = models.BigAutoField(primary_key=True)

    bq_id = models.CharField(max_length=50, null=True, blank=True)

    plan_type = models.ForeignKey(
        PlanType,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='plans'
    )

    title = models.CharField(max_length=100, null=True, blank=True)
    slug = models.SlugField(max_length=255, unique=True, null=True, blank=True)

    featured_image = models.ImageField(
    upload_to='plans/featured/',
    null=True,
    blank=True
)

    sub_title = models.CharField(max_length=255, null=True, blank=True)
    tag = models.CharField(max_length=50, null=True, blank=True)

    price = models.DecimalField(max_digits=10, decimal_places=2, default=0.00)
    sale_price = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)

    currency = models.CharField(max_length=10, default='USD')

    duration_type = models.CharField(
        max_length=10,
        choices=DURATION_CHOICES,
        default='mo'
    )

    call_duration = models.CharField(max_length=50, null=True, blank=True)
    sim_type = models.CharField(max_length=20, null=True, blank=True)

    duration_value = models.CharField(
        max_length=255,
        null=True,
        blank=True,
        help_text="Comma-separated number of units for duration_type"
    )

    features = models.JSONField(
        null=True,
        blank=True,
        help_text='Example: [{"icon_url": "url", "text": "your text"}]'
    )

    status = models.CharField(
        max_length=10,
        choices=STATUS_CHOICES,
        default='active'
    )

    order = models.IntegerField(default=0)

    image_url = models.CharField(max_length=255, null=True, blank=True)

    meta_title = models.CharField(max_length=255, null=True, blank=True)
    meta_slug = models.CharField(max_length=255, null=True, blank=True)
    meta_description = models.CharField(max_length=255, null=True, blank=True)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['order', '-created_at']
        db_table = 'plans'

    def __str__(self):
        return self.title or f"Plan #{self.id}"

    def save(self, *args, **kwargs):
        if not self.slug and self.title:
            self.slug = slugify(self.title)
        super().save(*args, **kwargs)
